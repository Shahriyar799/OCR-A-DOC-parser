"""Secure document-intake MVP."""
